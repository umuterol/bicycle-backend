const express = require("express");
const router = express.Router();
const bicycleController = require("../../controllers/bicycle/bicycle-coords-controller");


module.exports = router;