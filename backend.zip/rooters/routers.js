const bicyleRoute = require("./bicycle");
const smsRoute = require("./sms");
const userRoute = require("./user");
const walletRoute = require("./wallet");
const driveRoute = require("./drive");

module.exports = {
    bicyleRoute,
    smsRoute,
    userRoute,
    walletRoute,
    driveRoute,
}