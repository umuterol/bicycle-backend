const bicyleRoute = require("./bicycle");
const smsRoute = require("./sms");
const userRoute = require("./user");

module.exports = {
    bicyleRoute,
    smsRoute,
    userRoute,
}